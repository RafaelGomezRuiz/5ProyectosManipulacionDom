
let boton = document.getElementById('boton-cambiar-cita');
let cita = document.getElementById('cita');
let autor = document.getElementById('autor');


function generarEnteroAleatorio(minimo, maximo) {
  minimo = Math.ceil(minimo);
  maximo = Math.floor(maximo);
  
 return Math.floor(Math.random() * (maximo - minimo) + minimo);
}


function cambiarCita() {
  let indiceAleatorio = generarEnteroAleatorio(0, citas.length);
  cita.textContent = `${citas[indiceAleatorio].texto}`;
  autor.textContent = citas[indiceAleatorio].autor;
}
let indiceAleatorio = generarEnteroAleatorio(0, citas.length);
cambiarCita();

boton.addEventListener('click', cambiarCita);